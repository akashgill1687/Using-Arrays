//HomeWork-2 Program using arrays
#include<stdio.h>
//Function Declaration
void getMinFans(int fanSizes[],int numFans, int coolingNum);
int minHardDrives(int used[],int usedSize,int total[],int totalSize);
int findProfit(int cost[], int sales[], int unitSales[],int arraySize);
//Main function
int main()
{
	//Defining inputs for function to print fans required to cool the system
	int fanSizes[] ={1,2,3,4},numFans = 4,coolingNum = 5;
	//Defining inputs for function to calculate minimum hard drives
        int used[]={14,20,10,22}, usedSize=4, total[]={80,120,120,80}, totalSize=4;
	//Defining inputs for function to find maximum profit on items sold
        int cost[] = {4,3,7},sales[] = {5,6,9},unitSales[] = {1,1,1},arraySize = 3;
	//Calling function to print fans
	getMinFans(fanSizes,numFans,coolingNum);
	//Calling minimum hard drives function
        int minhd=minHardDrives(used,usedSize,total,totalSize);
	printf("%d\n",minhd);
	//Calling function to find profit
	int position=findProfit(cost,sales,unitSales,arraySize);
	printf("%d\n",position);
        return 0;
}

//Defining function to print fans
void getMinFans(int fanSizes[],int numFans, int coolingNum)
{
        int a,sum=0,i=2;
        //Declaring local array temp
        int temp[coolingNum];
        //Initiating values of local array temp
        for(a=0;a<coolingNum;a++)
        {
                temp[a]=0;
        }
        //Traversing, adding and removing values in temp array
        for(a=0;a<numFans;a++)
        {
                if (sum==coolingNum)
                {
                      break;
                }
                else if(sum>coolingNum)
                {
                         sum=sum-fanSizes[a-i];
                         temp[a-i]=0;
                           if (sum<coolingNum)
                           {
                                   sum=sum+fanSizes[a-i];
                                   temp[a-i]=fanSizes[a-i];
                                   i++;
                                   sum=sum-fanSizes[a-i];
                                   temp[a-i]=0;
                            }
                 }
                else
		{
                	 sum=sum+fanSizes[a];
                	 temp[a]=fanSizes[a];
                }
        }
        for(a=0;a<coolingNum;a++)
        {
             if(temp[a]!=0)
             //printing the output
             printf("%d ",temp[a]);
        }
        printf("\n");
}

//Defining function to print minimum hard drives
int minHardDrives(int used[],int usedSize,int total[],int totalSize)
{
	//sumused variable to calculate sum of  used space in hard drives
        int sumused=0;
	//Declaring local variable
        int a,b,i,temp,minhd=0;
	//To add all the used spaces in used array
        for(i=0;i<usedSize;i++)
        {
	      	sumused+=used[i];
        }
	//Sorting the totalSize array
	for(a=0;a<totalSize;a++)
	{
		for(b=a+1;b<totalSize;b++)
		{
			if (total[a]<total[b])
			{
				temp=total[a];
				total[a]=total[b];
				total[b]=temp;
			}
		}
	}
	//Comparing sum of used space with total array
	for(i=0;i<totalSize;i++)
	{
		if(total[i]>=sumused)
		{
			minhd++;
			break;
		}
		else if(sumused>total[i])
		{
			sumused=sumused-total[i];
			minhd++;
		}
	}
	return minhd;
}

//Defining function to find maximum profit
int findProfit(int cost[], int sales[], int unitSales[],int arraySize)
{
        int i,maximum,position=0;
        //Using an array profit to save profits on all items sold
        int profit[arraySize];
        for(i=0;i<arraySize;i++)
        {
                profit[i]=(sales[i]-cost[i])*unitSales[i];
        }
        //Assigning first member of array to maximum variable
        maximum=profit[0];
        //Traversing through the profit array to get the maximum profit and returning the position
        for (i=1;i<arraySize;i++)
        {
                if (profit[i] > maximum)
                {
                        maximum  = profit[i];
                        position = i;
                }
        }
        return position;
}
